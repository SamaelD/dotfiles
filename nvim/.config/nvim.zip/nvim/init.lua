vim.loader.enable()

require("config")
