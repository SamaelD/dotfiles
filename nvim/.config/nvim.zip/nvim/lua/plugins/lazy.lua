return {
    { "folke/lazy.nvim", tag = "stable" },
}
