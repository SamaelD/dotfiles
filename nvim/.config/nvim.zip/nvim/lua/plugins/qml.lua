return {
    {
        "peterhoeg/vim-qml",
        event = "BufRead",
        ft = { "qml" },
    }
}
