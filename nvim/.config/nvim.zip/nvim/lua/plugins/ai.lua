return {
    -- {
    --     "Exafunction/windsurf.nvim",
    --     dependencies = {
    --         "nvim-lua/plenary.nvim",
    --         "hrsh7th/nvim-cmp",
    --     },
    --     config = function()
    --         require("codeium").setup({
    --             enable_chat = true,
    --             virtual_text = {
    --                 enabled = true
    --             }
    --         })
    --     end,
    -- }
    -- {
    --     {
    --         "olimorris/codecompanion.nvim",
    --         opts = {},
    --         dependencies = {
    --             "nvim-lua/plenary.nvim",
    --             "nvim-treesitter/nvim-treesitter",
    --         },
    --         config = function()
    --             require("codecompanion").setup({
    --                 adapters = {
    --                     claude_sonnet = function()
    --                         return require("codecompanion.adapters").extend("anthropic", {
    --                             schema = { model = { default = "claude-3-5-sonnet" } },
    --                         })
    --                     end,
    --                     deepseek_coder = function()
    --                         return require("codecompanion.adapters").extend("deepseek", {
    --                             schema = { model = { default = "deepseek-coder" } },
    --                         })
    --                     end,
    --                 },
    --                 strategies = {
    --                     chat   = { adapter = "claude_sonnet" },
    --                     inline = { adapter = "deepseek_coder" },
    --                 },
    --                 display = {
    --                     action_palette = {
    --                         width = 95,
    --                         height = 10,
    --                         prompt = "Prompt ",
    --                         provider = "default",
    --                         opts = {
    --                             show_default_actions = true,
    --                             show_default_prompt_library = true,
    --                             title = "CodeCompanion actions",
    --                         },
    --                     },
    --                 },
    --             })
    --         end,
    --     },
    -- }
    {
        "yetone/avante.nvim",
        build = "make",
        event = "VeryLazy",
        version = false,
        dependencies = {
            "nvim-lua/plenary.nvim",
            "MunifTanjim/nui.nvim",
            "nvim-telescope/telescope.nvim",
            "hrsh7th/nvim-cmp",
            "folke/snacks.nvim", -- for input provider snacks
            "nvim-tree/nvim-web-devicons",
            {
                "HakonHarnes/img-clip.nvim",
                event = "VeryLazy",
                opts = {
                    default = {
                        embed_image_as_base64 = false,
                        prompt_for_file_name = false,
                        drag_and_drop = {
                            insert_mode = true,
                        },
                    },
                },
            },
            {
                'MeanderingProgrammer/render-markdown.nvim',
                opts = {
                    file_types = { "markdown", "Avante" },
                },
                ft = { "markdown", "Avante" },
            },
        },
    }
}
