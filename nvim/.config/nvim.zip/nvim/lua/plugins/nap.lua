return {
    {
        "liangxianzhe/nap.nvim",
        config = function()
            require("nap").setup({})
        end,
    }
}
