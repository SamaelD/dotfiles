return {
    "sindrets/diffview.nvim"
}
