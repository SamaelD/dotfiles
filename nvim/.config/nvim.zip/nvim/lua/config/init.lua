require("config.settings")
require("config.autocmds")
require("config.lazy")
require("config.mapping")
